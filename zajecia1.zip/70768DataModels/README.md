# 70768DataModels
70-768 Developing SQL Data Models (training materials)

https://drive.google.com/drive/folders/1sz0mQmBcqpMAQiUAL_6hv3XPIlrHedq5
